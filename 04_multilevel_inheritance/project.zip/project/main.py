from project.sports_car import SportsCar

sc = SportsCar()

print(sc.race())
print(sc.drive())
print(sc.move())