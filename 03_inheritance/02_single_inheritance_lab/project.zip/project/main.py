from project.dog import Dog

d = Dog()
print(d.bark())
print(d.eat())