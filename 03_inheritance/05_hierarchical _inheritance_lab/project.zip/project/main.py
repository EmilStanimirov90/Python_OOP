from project.cat import Cat
from project.dog import Dog

d = Dog()
c = Cat()
print(c.eat())
print(d.eat())
