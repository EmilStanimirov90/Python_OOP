class Hierarchy:
    pass
